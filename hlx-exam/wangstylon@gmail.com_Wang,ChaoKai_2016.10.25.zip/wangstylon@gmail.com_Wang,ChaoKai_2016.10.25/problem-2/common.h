#ifndef __COMMON_H__
#define __COMMON_H__

#define PRINT_SEM_KEY "problem-2_print_lock"

#define INT_SEM_KEY "problem-2_integer_semaphore"
#define INT_QUEUE_KEY "/problem-2_integer_shm"

#endif //__COMMON_H__
