
Author: Chao Kai (Stylon) Wang (wangstylon@gmail.com)


Problem 1: unfinished

        Usage: 
        
        $ cd problem-1
        $ make
        $ export LD_LIBRARY_PATH=`pwd`
        $ ./problem-1 alltraffic.pcap

        As demonstrated in zcompress.cpp, Zerocompress/decompress 
        is not working as expected. So far I cannot decode compressed
        FTDC messages, not to mention the fields inside FTDC payload.

        

